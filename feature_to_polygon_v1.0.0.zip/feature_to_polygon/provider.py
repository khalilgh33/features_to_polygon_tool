# -*- coding: utf-8 -*-
import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon


class FeatureToPolygonProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        from .algorithm import FeatureToPolygonAlgorithm
        self.addAlgorithm(FeatureToPolygonAlgorithm())

    def id(self):
        return "featuretopolygon"

    def name(self):
        return "Feature To Polygon"

    def longName(self):
        return self.name()

    def icon(self):
        return QIcon(self._icon_path())

    def _icon_path(self):
        return os.path.join(os.path.dirname(__file__), "icon.png")
