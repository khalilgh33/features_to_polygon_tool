# -*- coding: utf-8 -*-
"""
Feature To Polygon Algorithm

Logic:
  1. Accept multiple input layers (polygon, line, point - any mix)
  2. Optional: clip all inputs to a clip mask polygon
  3. Extract boundaries from polygons, use lines directly, buffer points
  4. Merge + node all geometries with unary_union
  5. Polygonize enclosed areas
  6. Optionally clip result to union of input polygons
  7. For each output polygon, assign attributes from largest-overlap
     source feature per input layer (no NULLs)
  8. Output has union of all fields from all input layers

References:
  - Shapely: https://shapely.readthedocs.io/en/stable/
  - QGIS Processing API: https://qgis.org/pyqgis/master/core/QgsProcessingAlgorithm.html
"""

import os
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
    QgsFeatureSink,
    QgsFeature,
    QgsGeometry,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsProject,
    QgsFields,
    QgsField,
)
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

try:
    from shapely.ops import polygonize, unary_union
    from shapely.geometry import MultiPolygon, Polygon
    import shapely.wkt
    SHAPELY_OK = True
except ImportError:
    SHAPELY_OK = False


def _to_shapely(qgs_geom):
    return shapely.wkt.loads(qgs_geom.asWkt())


def _to_qgs(shp_geom):
    return QgsGeometry.fromWkt(shp_geom.wkt)


def _safe_shapely(qgs_geom):
    """Convert QgsGeometry to valid Shapely geometry, or None."""
    try:
        shp = _to_shapely(qgs_geom)
        if not shp.is_valid:
            shp = shp.buffer(0)
        return None if shp.is_empty else shp
    except Exception:
        return None


def _build_field_union(layers):
    """
    Build a QgsFields object as the union of all fields from all layers.
    Duplicate field names get a layer-index suffix to avoid collisions.
    Returns (QgsFields, list of (layer_index, original_field_name, output_field_name))
    """
    out_fields = QgsFields()
    field_map  = []  # (layer_idx, orig_name, out_name)
    seen_names = {}  # out_name -> count

    for li, layer in enumerate(layers):
        for field in layer.fields():
            base = field.name()[:10]  # shapefile limit
            if base in seen_names:
                seen_names[base] += 1
                out_name = (base[:8] + "_" + str(seen_names[base]))[:10]
            else:
                seen_names[base] = 0
                out_name = base

            new_field = QgsField(out_name, field.type())
            out_fields.append(new_field)
            field_map.append((li, field.name(), out_name))

    # Add our own metadata fields
    out_fields.append(QgsField("ftp_id",  QVariant.Int))
    out_fields.append(QgsField("area_m2", QVariant.Double))

    return out_fields, field_map


class FeatureToPolygonAlgorithm(QgsProcessingAlgorithm):

    INPUT_LAYERS  = "INPUT_LAYERS"
    CLIP_MASK     = "CLIP_MASK"
    POINT_BUFFER  = "POINT_BUFFER"
    CLIP_OUTPUT   = "CLIP_OUTPUT"
    OUTPUT        = "OUTPUT"

    def tr(self, s):
        return QCoreApplication.translate("FeatureToPolygon", s)

    def createInstance(self):
        return FeatureToPolygonAlgorithm()

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), "icon.png"))

    def name(self):
        return "featuretopolygon"

    def displayName(self):
        return self.tr("Feature To Polygon")

    def group(self):
        return self.tr("Vector Geoprocessing")

    def groupId(self):
        return "vectorgeoprocessing"

    def shortHelpString(self):
        return self.tr(
            "Generates polygons from all enclosed areas formed by combining "
            "multiple input layers (polygons, lines, points).\n\n"
            "Each output polygon inherits attributes from the largest-overlap "
            "source feature in each input layer. No NULLs — always the best match.\n\n"
            "Optional clip mask crops all inputs before processing.\n\n"
            "Requires Shapely >= 1.7:  pip install shapely"
        )

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                self.tr("Input Layers (polygon, line, point — any combination)"),
                QgsProcessing.TypeVectorAnyGeometry,
            )
        )

        clip_param = QgsProcessingParameterFeatureSource(
            self.CLIP_MASK,
            self.tr("Clip mask (optional — clips all inputs before processing)"),
            [QgsProcessing.TypeVectorPolygon],
            optional=True,
        )
        self.addParameter(clip_param)

        point_param = QgsProcessingParameterNumber(
            self.POINT_BUFFER,
            self.tr("Point buffer radius in map units (optional — only for point layers)"),
            type=QgsProcessingParameterNumber.Double,
            defaultValue=10.0,
            optional=True,
            minValue=0.0,
        )
        self.addParameter(point_param)

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.CLIP_OUTPUT,
                self.tr("Clip output to input polygon extent"),
                defaultValue=True,
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr("Output Polygons"),
                QgsProcessing.TypeVectorPolygon,
            )
        )

    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        if not SHAPELY_OK:
            raise QgsProcessingException(
                "Shapely is not installed.\n"
                "Open OSGeo4W Shell and run:  pip install shapely"
            )

        # ── 1. Read parameters ──────────────────────────────────────────
        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        if not layers:
            raise QgsProcessingException("No input layers provided.")

        clip_mask_source = self.parameterAsSource(parameters, self.CLIP_MASK, context)
        clip_output      = self.parameterAsBoolean(parameters, self.CLIP_OUTPUT, context)
        point_buffer     = self.parameterAsDouble(parameters, self.POINT_BUFFER, context)
        if point_buffer is None or point_buffer <= 0:
            point_buffer = None

        ref_crs  = layers[0].crs()
        n_layers = len(layers)

        # ── 2. Build clip mask geometry (optional) ──────────────────────
        clip_shp = None
        if clip_mask_source is not None:
            feedback.setProgressText("Building clip mask...")
            mask_parts = []
            mask_transform = None
            if clip_mask_source.sourceCrs() != ref_crs:
                mask_transform = QgsCoordinateTransform(
                    clip_mask_source.sourceCrs(), ref_crs, QgsProject.instance()
                )
            for feat in clip_mask_source.getFeatures():
                g = feat.geometry()
                if g is None or g.isEmpty():
                    continue
                if mask_transform:
                    g.transform(mask_transform)
                shp = _safe_shapely(g)
                if shp:
                    mask_parts.append(shp)
            if mask_parts:
                clip_shp = unary_union(mask_parts)

        # ── 3. Build output fields (union of all input fields) ──────────
        out_fields, field_map = _build_field_union(layers)

        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            out_fields, QgsWkbTypes.Polygon, ref_crs
        )
        if sink is None:
            raise QgsProcessingException("Could not create output layer.")

        # ── 4. Collect geometries + store features per layer ────────────
        # layer_features[li] = list of (shapely_geom, attribute_dict)
        all_lines     = []
        union_poly    = None
        layer_features = [[] for _ in range(n_layers)]

        for li, layer in enumerate(layers):
            if feedback.isCanceled():
                return {}

            feedback.setProgressText(
                f"Reading layer {li+1}/{n_layers}: {layer.name()}"
            )

            needs_transform = layer.crs() != ref_crs
            transform = None
            if needs_transform:
                transform = QgsCoordinateTransform(
                    layer.crs(), ref_crs, QgsProject.instance()
                )

            geom_type = layer.geometryType()
            features  = list(layer.getFeatures())
            n_feat    = len(features)

            for i, feat in enumerate(features):
                if feedback.isCanceled():
                    return {}

                qgs_geom = feat.geometry()
                if qgs_geom is None or qgs_geom.isEmpty():
                    continue

                if needs_transform:
                    qgs_geom.transform(transform)

                # Apply clip mask if set
                if clip_shp is not None:
                    shp_raw = _safe_shapely(qgs_geom)
                    if shp_raw is None:
                        continue
                    try:
                        shp_raw = shp_raw.intersection(clip_shp)
                        if shp_raw.is_empty:
                            continue
                        qgs_geom = _to_qgs(shp_raw)
                    except Exception:
                        continue

                shp = _safe_shapely(qgs_geom)
                if shp is None:
                    continue

                # Store feature attributes for later assignment
                attr_dict = {f.name(): feat[f.name()] for f in layer.fields()}
                layer_features[li].append((shp, attr_dict))

                # Add to boundary pool
                if geom_type == QgsWkbTypes.PolygonGeometry:
                    all_lines.append(shp.boundary)
                    union_poly = shp if union_poly is None else union_poly.union(shp)

                elif geom_type == QgsWkbTypes.LineGeometry:
                    all_lines.append(shp)

                elif geom_type == QgsWkbTypes.PointGeometry:
                    if point_buffer is None:
                        feedback.pushWarning(
                            f"Point feature {feat.id()} skipped — no buffer radius set."
                        )
                        continue
                    buffered = shp.buffer(point_buffer, resolution=16)
                    all_lines.append(buffered.boundary)
                    layer_features[li][-1] = (buffered, attr_dict)

                feedback.setProgress(int(60 * (li * n_feat + i) / max(n_layers * n_feat, 1)))

        if not all_lines:
            raise QgsProcessingException("No usable geometries found.")

        # ── 5. Merge, node, polygonize ──────────────────────────────────
        feedback.setProgressText("Merging and noding boundaries...")
        feedback.setProgress(60)
        merged = unary_union(all_lines)
        feedback.setProgress(68)

        feedback.setProgressText("Polygonizing enclosed areas...")
        result_polys = list(polygonize(merged))
        feedback.setProgress(75)

        if not result_polys:
            raise QgsProcessingException(
                "No enclosed areas found. Check that lines cross polygon "
                "boundaries and form closed regions."
            )

        # ── 6. Clip output to polygon union (optional) ──────────────────
        if clip_output and union_poly is not None:
            feedback.setProgressText("Clipping output to polygon extent...")
            clipped = []
            for poly in result_polys:
                if feedback.isCanceled():
                    return {}
                try:
                    inter = poly.intersection(union_poly)
                    if inter.is_empty:
                        continue
                    if inter.geom_type == "Polygon":
                        clipped.append(inter)
                    elif inter.geom_type == "MultiPolygon":
                        clipped.extend(inter.geoms)
                except Exception:
                    continue
            result_polys = clipped
        feedback.setProgress(82)

        # ── 7. Assign attributes (largest overlap per layer) ────────────
        feedback.setProgressText("Assigning attributes to output polygons...")
        n_out = len(result_polys)

        for i, poly in enumerate(result_polys):
            if feedback.isCanceled():
                return {}

            if not poly.is_valid:
                poly = poly.buffer(0)
            if poly.is_empty:
                continue

            # For each layer, find the feature with largest overlap area
            # layer_attrs[li] = attribute dict of best-match feature
            layer_attrs = {}
            for li, feats in enumerate(layer_features):
                best_area  = -1
                best_attrs = None

                for (src_shp, attr_dict) in feats:
                    try:
                        overlap = poly.intersection(src_shp).area
                    except Exception:
                        overlap = 0.0

                    if overlap > best_area:
                        best_area  = overlap
                        best_attrs = attr_dict

                # If no overlap at all, pick the spatially nearest feature
                if (best_attrs is None or best_area == 0) and feats:
                    min_dist   = float('inf')
                    best_attrs = feats[0][1]
                    for (src_shp, attr_dict) in feats:
                        try:
                            d = poly.distance(src_shp)
                        except Exception:
                            d = float('inf')
                        if d < min_dist:
                            min_dist   = d
                            best_attrs = attr_dict

                layer_attrs[li] = best_attrs or {}

            # Build attribute row in output field order
            row = []
            for (li, orig_name, out_name) in field_map:
                row.append(layer_attrs[li].get(orig_name, None))

            row.append(i + 1)              # ftp_id
            row.append(round(poly.area, 4))  # area_m2

            feat_out = QgsFeature(out_fields)
            feat_out.setGeometry(_to_qgs(poly))
            feat_out.setAttributes(row)
            sink.addFeature(feat_out, QgsFeatureSink.FastInsert)

            feedback.setProgress(82 + int(18 * i / max(n_out, 1)))

        feedback.setProgress(100)
        feedback.pushInfo(
            f"Done. {n_out} polygon(s) generated from {n_layers} input layer(s)."
        )

        return {self.OUTPUT: dest_id}
